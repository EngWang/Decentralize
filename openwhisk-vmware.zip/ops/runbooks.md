# Runbook – DevOps/Infra (Local)

## Standalone
- Start: `scripts/02_standalone_up.sh`
- Logs: `scripts/04_standalone_logs.sh`
- Stop: `scripts/03_standalone_down.sh`

## k3d/Helm
- Pods: `kubectl -n openwhisk get pods`
- Logs controller: `kubectl -n openwhisk logs deploy/controller -f`
- Logs invoker: `kubectl -n openwhisk logs -l name=invoker -f`
- Restart invoker: `kubectl -n openwhisk rollout restart deploy/invoker`
- Health: `curl -s http://$(bash scripts/detect_ip.sh)/ping`

## Sự cố thường gặp
- 5xx từ gateway: kiểm Kafka/CouchDB pod
- Cold start lâu: giảm concurrency, bật sẵn runtime phổ biến
- Invoker down: kiểm tra containerFactory (k8s), tài nguyên node
