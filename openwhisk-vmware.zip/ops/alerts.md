# Alerts (local tối thiểu – thủ công/quan sát)
- Controller 5xx tăng (xem logs)
- Invoker crashloop
- Kafka not ready / lag cao
- CouchDB disk usage > 80%

> Ghi chú tiêu chí và cách xử lý vào repo để team tham khảo.
