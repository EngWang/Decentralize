#!/usr/bin/env bash
set -euo pipefail
NS="openwhisk"
AUTH="$(kubectl -n "$NS" get cm whisk.auth -o jsonpath='{.data.system}' 2>/dev/null || true)"
[[ -z "$AUTH" ]] && AUTH="devUser:devPass123"
AP="$(wsk property get --apihost 2>/dev/null | awk '{print $2}' || true)"
[[ -z "$AP" ]] && AP="$(./scripts/detect_ip.sh)"
wsk property set --auth "$AUTH" --apihost "$AP" --apiversion v1
echo "wsk configured with auth: $AUTH and apihost: $AP"
