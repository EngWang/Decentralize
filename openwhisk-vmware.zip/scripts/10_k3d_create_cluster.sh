#!/usr/bin/env bash
set -euo pipefail
if ! command -v k3d >/dev/null 2>&1; then
  curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash
fi
k3d cluster create ow --agents 2 --servers 1 --api-port 0.0.0.0:6445 --port "80:80@loadbalancer" --port "443:443@loadbalancer"
kubectl wait --for=condition=Ready nodes --all --timeout=180s
kubectl create ns openwhisk || true
echo "k3d 'ow' created."
