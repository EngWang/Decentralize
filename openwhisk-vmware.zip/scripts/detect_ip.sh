#!/usr/bin/env bash
set -euo pipefail
detect_ip() {
  if command -v ip >/dev/null 2>&1; then
    dev="$(ip route 2>/dev/null | awk '/default/ {print $5; exit}')"
    if [[ -n "${dev:-}" ]]; then
      ip -4 addr show "$dev" | awk '/inet / {print $2}' | cut -d/ -f1 | head -n1
      return
    fi
  fi
  hostname -I 2>/dev/null | tr ' ' '\n' | grep -E '^(10\.|172\.(1[6-9]|2[0-9]|3[0-1])\.|192\.168\.)' | head -n1
}
IP="$(detect_ip || true)"
[[ -z "${IP:-}" ]] && IP="127.0.0.1"
echo "$IP"
