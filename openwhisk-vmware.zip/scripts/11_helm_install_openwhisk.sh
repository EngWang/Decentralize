#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v helm >/dev/null 2>&1; then
  curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
fi
helm repo add openwhisk https://openwhisk.apache.org/charts
helm repo update
API_HOST="${API_HOST:-$("$DIR/scripts/detect_ip.sh")}"
echo "Using API_HOST=${API_HOST}"
helm upgrade --install ow openwhisk/openwhisk \
  --namespace openwhisk \
  -f "$DIR/k8s/values.yaml" \
  --set whisk.ingress.apiHostName="${API_HOST}" \
  --set whisk.ingress.apiHostPort=80 \
  --set whisk.ingress.tls.enabled=false \
  --set invoker.count=2
kubectl wait --namespace openwhisk --for=condition=Ready pods --all --timeout=900s
wsk property set --apihost "${API_HOST}" --apiversion v1
echo "OpenWhisk (Helm) at http://${API_HOST}/api/v1"
