#!/usr/bin/env bash
set -euo pipefail
docker logs -f ow-standalone
