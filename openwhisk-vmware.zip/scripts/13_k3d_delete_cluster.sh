#!/usr/bin/env bash
set -euo pipefail
k3d cluster delete ow || true
