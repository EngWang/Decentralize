#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
docker compose -f "$DIR/compose/docker-compose.standalone.yml" up -d
echo "Đợi OpenWhisk Standalone sẵn sàng..."
for i in {1..60}; do
  st="$(docker inspect -f '{{.State.Health.Status}}' ow-standalone 2>/dev/null || true)"
  [[ "$st" == "healthy" ]] && break
  sleep 3
done
IP="${API_HOST:-$("$DIR/scripts/detect_ip.sh")}"
AUTH="23bc2d02-0ff6-4d1a-bf1a-38d3f6cf23bc:9c0a0c9d-1111-2222-3333-444444444444"
wsk property set --apihost "${IP}:3233" --auth "$AUTH" --apiversion v1
echo "Standalone ready at https://${IP}:3233/api/v1"
