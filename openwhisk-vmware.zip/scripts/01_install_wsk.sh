#!/usr/bin/env bash
set -euo pipefail
OS="$(uname -s | tr '[:upper:]' '[:lower:]')"
ARCH="$(uname -m)"
[[ "$ARCH" == "x86_64" ]] && ARCH=amd64
[[ "$ARCH" == "aarch64" ]] && ARCH=arm64
curl -L -o wsk "https://github.com/apache/openwhisk-cli/releases/latest/download/wsk_${OS}_${ARCH}"
chmod +x wsk && sudo mv wsk /usr/local/bin/wsk
wsk -v || true
