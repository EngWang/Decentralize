#!/bin/bash
echo "=== STOPPING OPENWHISK CLUSTER ==="

services=("nginx" "couchdb")

for service in "${services[@]}"; do
    echo "🛑 Stopping $service..."
    docker stop $service 2>/dev/null && echo "✅ $service stopped" || echo "⚠️  $service was not running"
done

echo ""
echo "📊 Current running containers:"
docker ps --format "table {{.Names}}\t{{.Status}}"