#!/bin/bash
echo "=== Stopping OpenWhisk Cluster ==="

docker stop nginx invoker2 invoker1 controller couchdb

echo "✅ All services stopped"
docker ps