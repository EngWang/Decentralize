#!/bin/bash
echo "=== SYSTEM RESOURCES MONITORING ==="
echo "📅 $(date)"
echo ""

# System info
echo "🖥️  HOST SYSTEM:"
echo "   CPU: $(grep -c ^processor /proc/cpuinfo) cores"
echo "   RAM: $(free -h | grep Mem | awk '{print $2}') total"
echo "   OS: $(grep PRETTY_NAME /etc/os-release | cut -d= -f2 | tr -d '"')"

# Resource usage
echo ""
echo "📊 RESOURCE USAGE:"
echo "   CPU: $(top -bn1 | grep "Cpu(s)" | awk '{print $2 "% user, " $4 "% system"}')"
echo "   Memory: $(free -h | grep Mem | awk '{print $3 " / " $2 " (" $3/$2*100 "%%)"}')"
echo "   Disk: $(df -h / | awk 'NR==2 {print $3 " / " $2 " (" $5 ")"}')"

# Docker status
echo ""
echo "🐳 DOCKER STATUS:"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# Service logs preview
echo ""
echo "📋 SERVICE LOGS PREVIEW:"
echo "📝 CouchDB (last 3 lines):"
docker logs couchdb --tail 3 2>/dev/null | sed 's/^/   /'
echo "📝 Nginx (last 3 lines):"
docker logs nginx --tail 3 2>/dev/null | sed 's/^/   /'

# Network check
echo ""
echo "🌐 NETWORK CONNECTIVITY:"
echo "   CouchDB: $(curl -s -o /dev/null -w "%{http_code}" http://localhost:5984/ || echo "DOWN")"
echo "   Nginx: $(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/ || echo "DOWN")"