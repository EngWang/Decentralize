#!/bin/bash
echo "=== System Resources Monitoring ==="

echo "📊 CPU Usage:"
top -bn1 | grep "Cpu(s)" | awk '{print "CPU: " $2 "%"}'

echo "💾 Memory Usage:"
free -h | grep Mem | awk '{print "Memory: " $3 " / " $2}'

echo "💽 Disk Usage:"
df -h / | awk 'NR==2 {print "Disk: " $3 " / " $2 " (" $5 ")"}'

echo "🐳 Docker Containers Status:"
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

echo "📈 Nginx Logs (last 5 lines):"
docker logs nginx --tail 5 2>/dev/null || echo "Nginx container not found"

echo "🎮 Controller Logs (last 5 lines):"
docker logs controller --tail 5 2>/dev/null || echo "Controller container not found"