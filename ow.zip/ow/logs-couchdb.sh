#!/bin/bash
echo "=== COUCHDB LOGS ==="
echo "📁 Following CouchDB logs (Ctrl+C to exit)..."
echo "💡 Look for database initialization messages"
echo "💡 Monitor for any connection errors"
echo ""
docker logs -f couchdb