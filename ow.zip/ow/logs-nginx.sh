#!/bin/bash
echo "=== NGINX LOGS ==="
echo "📁 Following Nginx logs (Ctrl+C to exit)..."
echo "💡 Access logs show incoming requests"
echo "💡 Error logs show any issues"
echo ""
docker logs -f nginx