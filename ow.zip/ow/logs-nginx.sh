#!/bin/bash
echo "=== Nginx Logs ==="
docker logs -f nginx