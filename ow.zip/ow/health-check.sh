#!/bin/bash
echo "=== OpenWhisk Services Health Check ==="

services=("couchdb" "controller" "invoker1" "invoker2" "nginx")

for service in "${services[@]}"; do
    if docker ps | grep -q $service; then
        echo "✅ $service is running"
    else
        echo "❌ $service is NOT running"
    fi
done

echo ""
echo "🔍 Checking service ports:"
echo "CouchDB: $(nc -z localhost 5984 && echo "OK" || echo "FAILED")"
echo "Controller: $(nc -z localhost 8888 && echo "OK" || echo "FAILED")"
echo "Nginx: $(nc -z localhost 80 && echo "OK" || echo "FAILED")"