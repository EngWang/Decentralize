#!/bin/bash
echo "=== Deploying OpenWhisk Cluster ==="

# Create custom network
docker network create openwhisk-net

# Deploy CouchDB
echo "Deploying CouchDB..."
docker run -d --name couchdb --network openwhisk-net -p 5984:5984 couchdb:3.3

# Wait for CouchDB to be ready
sleep 10

# Deploy OpenWhisk Controller
echo "Deploying OpenWhisk Controller..."
docker run -d --name controller --network openwhisk-net -p 8888:8888 openwhisk/controller

# Deploy 2 Invokers
echo "Deploying Invoker 1..."
docker run -d --name invoker1 --network openwhisk-net openwhisk/invoker

echo "Deploying Invoker 2..."
docker run -d --name invoker2 --network openwhisk-net openwhisk/invoker

# Deploy Nginx
echo "Deploying Nginx..."
docker run -d --name nginx --network openwhisk-net -p 80:80 -v $(pwd)/nginx.conf:/etc/nginx/nginx.conf nginx

echo "✅ OpenWhisk cluster deployment completed!"
docker ps