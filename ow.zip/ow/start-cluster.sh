#!/bin/bash
echo "=== Starting OpenWhisk Cluster ==="

docker start couchdb controller invoker1 invoker2 nginx

echo "✅ All services started"
./health-check.sh