#!/bin/bash
echo "=== Cleaning Up OpenWhisk Cluster ==="

docker stop nginx invoker2 invoker1 controller couchdb 2>/dev/null
docker rm nginx invoker2 invoker1 controller couchdb 2>/dev/null
docker network rm openwhisk-net 2>/dev/null

echo "✅ Cleanup completed"
docker ps -a