#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if ! command -v helm >/dev/null 2>&1; then
  curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash
fi
helm repo add openwhisk https://openwhisk.apache.org/charts || true
helm repo update
API_HOST="$("$DIR/scripts/detect_ip.sh")"
API_PORT="${LB_HTTP_PORT:-8080}"
helm upgrade --install ow openwhisk/openwhisk -n openwhisk --create-namespace -f "$DIR/k8s/values.yaml" --set whisk.ingress.apiHostName="${API_HOST}" --set whisk.ingress.apiHostPort="${API_PORT}" --set whisk.ingress.tls.enabled=false --set invoker.count=2
kubectl wait -n openwhisk --for=condition=Ready pods --all --timeout=900s
echo "OpenWhisk ready at http://${API_HOST}:${API_PORT}/api/v1"
