#!/usr/bin/env bash
set -euo pipefail
NS="openwhisk"
AUTH="$(kubectl -n "$NS" get cm whisk.auth -o jsonpath='{.data.system}' 2>/dev/null || echo devUser:devPass123)"
HOST="$(bash scripts/detect_ip.sh)"
PORT="${LB_HTTP_PORT:-8080}"
wsk property set --apihost "${HOST}:${PORT}" --auth "$AUTH" --apiversion v1
wsk property get
