#!/usr/bin/env bash
set -euo pipefail
if command -v wsk >/dev/null 2>&1; then
  echo "[wsk] Already installed:"
  wsk || true
  exit 0
fi
OS="linux"
ARCH="$(uname -m)"
case "$ARCH" in
  x86_64) ARCH=amd64 ;;
  aarch64) ARCH=arm64 ;;
esac
URL="https://github.com/apache/openwhisk-cli/releases/latest/download/wsk_${OS}_${ARCH}"
echo "[wsk] Downloading $URL"
curl -fsSL "$URL" -o /tmp/wsk
chmod +x /tmp/wsk
sudo mv /tmp/wsk /usr/local/bin/wsk
wsk -v
