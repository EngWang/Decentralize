#!/usr/bin/env bash
set -euo pipefail
is_free() {
  local port="$1"
  if command -v ss >/dev/null 2>&1; then
    ! ss -ltn "( sport = :$port )" | grep -q ":$port"
  elif command -v lsof >/dev/null 2>&1; then
    ! lsof -iTCP:$port -sTCP:LISTEN >/dev/null 2>&1
  else
    return 0
  fi
}
if [[ -z "${LB_HTTP_PORT:-}" || -z "${LB_HTTPS_PORT:-}" ]]; then
  if ! is_free 80 || ! is_free 443; then
    export LB_HTTP_PORT=8080
    export LB_HTTPS_PORT=8443
  else
    export LB_HTTP_PORT=80
    export LB_HTTPS_PORT=443
  fi
fi
echo "[port_pick] Using LB_HTTP_PORT=$LB_HTTP_PORT, LB_HTTPS_PORT=$LB_HTTPS_PORT"
