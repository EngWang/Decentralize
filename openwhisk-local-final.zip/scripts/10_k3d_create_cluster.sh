#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$DIR/scripts/port_pick.sh"
if ! command -v k3d >/dev/null 2>&1; then
  curl -s https://raw.githubusercontent.com/k3d-io/k3d/main/install.sh | bash
fi
k3d cluster create ow --agents 2 --servers 1 --api-port 0.0.0.0:6445 --port "${LB_HTTP_PORT}:80@loadbalancer" --port "${LB_HTTPS_PORT}:443@loadbalancer"
export KUBECONFIG="$(k3d kubeconfig write ow)"
kubectl config use-context k3d-ow >/dev/null 2>&1 || true
kubectl wait --for=condition=Ready nodes --all --timeout=300s
kubectl create ns openwhisk || true
echo "[k3d] Cluster created on port ${LB_HTTP_PORT}"
