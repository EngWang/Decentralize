#!/usr/bin/env bash
set -euo pipefail
tmpfile="$(mktemp)"
cat > "$tmpfile" <<'EOF'
function main(params) {
  const name = params.name || "Anh Quang";
  const greeting = params.greeting || "Xin chao";
  return { message: `${greeting}, ${name}!` };
}
EOF
wsk action update hello-js --kind nodejs:18 "$tmpfile"
wsk action invoke hello-js -p name "Anh Quang" --result
rm -f "$tmpfile"
