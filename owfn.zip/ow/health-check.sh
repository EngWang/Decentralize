#!/bin/bash
echo "=== OPENWHISK INFRASTRUCTURE HEALTH CHECK ==="
echo "⏰ $(date)"
echo ""

services=("couchdb" "nginx")
all_healthy=true

for service in "${services[@]}"; do
    if docker ps | grep -q $service; then
        echo "✅ $service container is RUNNING"
        
        # Check service-specific health
        case $service in
            "couchdb")
                status=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:5984/ || echo "000")
                if [ "$status" = "200" ]; then
                    echo "   🔗 HTTP Status: $status (HEALTHY)"
                else
                    echo "   🔗 HTTP Status: $status (UNHEALTHY)"
                    all_healthy=false
                fi
                ;;
            "nginx")
                status=$(curl -s -o /dev/null -w "%{http_code}" http://localhost:8080/ || echo "000")
                if [ "$status" = "200" ] || [ "$status" = "502" ] || [ "$status" = "503" ]; then
                    echo "   🔗 HTTP Status: $status (RUNNING - backend may be down)"
                else
                    echo "   🔗 HTTP Status: $status (UNHEALTHY)"
                    all_healthy=false
                fi
                ;;
        esac
    else
        echo "❌ $service container is NOT RUNNING"
        all_healthy=false
    fi
    echo ""
done

# Port check
echo "🔌 PORT AVAILABILITY:"
netstat -tuln | grep -E ":(5984|8080)" | while read line; do
    echo "   $line"
done

# Final status
echo ""
if [ "$all_healthy" = true ]; then
    echo "🎉 ALL SERVICES ARE HEALTHY!"
    echo "🌐 CouchDB UI: http://localhost:5984/_utils"
    echo "🚀 Nginx: http://localhost:8080"
else
    echo "⚠️  SOME SERVICES NEED ATTENTION"
    echo "💡 Run './monitor-resources.sh' for detailed logs"
fi