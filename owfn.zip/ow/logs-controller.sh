#!/bin/bash
echo "=== Controller Logs ==="
docker logs -f controller