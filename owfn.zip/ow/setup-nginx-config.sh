#!/bin/bash
echo "=== SETTING UP NGINX CONFIG ==="

if [ -f "nginx.conf" ]; then
    echo "📁 Copying nginx.conf to container..."
    docker cp nginx.conf nginx:/etc/nginx/nginx.conf
    docker exec nginx nginx -s reload
    echo "✅ Nginx config updated successfully"
else
    echo "❌ nginx.conf file not found in current directory"
    echo "💡 Please make sure nginx.conf exists in: $(pwd)"
fi