#!/bin/bash
echo "=== STARTING OPENWHISK CLUSTER ==="

services=("couchdb" "nginx")

for service in "${services[@]}"; do
    echo "🚀 Starting $service..."
    docker start $service 2>/dev/null && echo "✅ $service started" || echo "⚠️  $service may already be running"
done

echo ""
echo "⏳ Waiting for services to initialize..."
sleep 10

echo ""
./health-check.sh