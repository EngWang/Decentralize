#!/bin/bash
echo "=== DEPLOYING OPENWHISK INFRASTRUCTURE ==="

# Cleanup first
echo "🧹 Cleaning up existing containers..."
docker stop couchdb nginx 2>/dev/null
docker rm couchdb nginx 2>/dev/null
docker network rm openwhisk-net 2>/dev/null

# Create network
echo "🌐 Creating Docker network..."
docker network create openwhisk-net

# Deploy CouchDB
echo "📦 Deploying CouchDB..."
docker run -d --name couchdb \
  --network openwhisk-net \
  -p 5984:5984 \
  -p 5986:5986 \
  -e COUCHDB_USER=admin \
  -e COUCHDB_PASSWORD=password \
  -v couchdb_data:/opt/couchdb/data \
  couchdb:3.3

# Wait for CouchDB
echo "⏳ Waiting for CouchDB to start (30 seconds)..."
sleep 30

# Check CouchDB status
echo "🔍 Checking CouchDB status..."
curl -f http://localhost:5984/ || echo "⚠️  CouchDB may need more time to start"

# Initialize CouchDB databases for OpenWhisk
echo "🗃️ Initializing OpenWhisk databases..."
curl -s -X PUT http://admin:password@localhost:5984/_users || true
curl -s -X PUT http://admin:password@localhost:5984/_replicator || true
curl -s -X PUT http://admin:password@localhost:5984/_global_changes || true

# Deploy Nginx WITHOUT volume mount (sử dụng copy method)
echo "🚀 Deploying Nginx (API Gateway)..."

# First create nginx container without config
docker run -d --name nginx \
  --network openwhisk-net \
  -p 8080:80 \
  nginx:alpine

# Wait a bit for container to start
sleep 5

# Copy nginx config into container
if [ -f "nginx.conf" ]; then
    echo "📁 Copying nginx.conf to container..."
    docker cp nginx.conf nginx:/etc/nginx/nginx.conf
    docker exec nginx nginx -s reload
    echo "✅ Nginx config updated"
else
    echo "⚠️  nginx.conf not found, using default config"
fi

echo ""
echo "✅ DEPLOYMENT COMPLETED!"
echo "📊 Services:"
echo "   • CouchDB: http://localhost:5984/_utils (admin/password)"
echo "   • Nginx: http://localhost:8080"
echo "   • CouchDB Admin: http://localhost:5986/_utils"
echo ""
echo "🔍 Run './health-check.sh' to verify deployment"
docker ps