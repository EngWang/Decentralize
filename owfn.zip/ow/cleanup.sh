#!/bin/bash
echo "=== CLEANING UP OPENWHISK INFRASTRUCTURE ==="

echo "🧹 Stopping and removing containers..."
docker stop nginx couchdb 2>/dev/null
docker rm nginx couchdb 2>/dev/null

echo "🗑️  Removing network..."
docker network rm openwhisk-net 2>/dev/null

echo "💾 Removing volumes..."
docker volume rm couchdb_data 2>/dev/null || true

echo ""
echo "✅ CLEANUP COMPLETED!"
echo "📊 Remaining containers:"
docker ps -a --format "table {{.Names}}\t{{.Status}}\t{{.Image}}" | head -10

echo ""
echo "💡 To remove all Docker data: 'docker system prune -f' (careful!)"